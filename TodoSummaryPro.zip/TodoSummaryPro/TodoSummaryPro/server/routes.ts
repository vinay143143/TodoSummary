import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertTodoSchema, 
  summarySchema, 
  slackConfigSchema,
  TodoPriority
} from "@shared/schema";
import { ZodError } from "zod";
import axios from "axios";
import { WebClient } from "@slack/web-api";
import OpenAI from "openai";

// Initialize OpenAI API client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || "",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handling middleware
  const handleError = (res: Response, error: unknown) => {
    console.error("API Error:", error);
    
    if (error instanceof ZodError) {
      return res.status(400).json({ 
        message: "Validation error", 
        errors: error.errors 
      });
    }
    
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    return res.status(500).json({ message: errorMessage });
  };

  // GET all todos
  app.get("/api/todos", async (_req: Request, res: Response) => {
    try {
      const todos = await storage.getAllTodos();
      res.json(todos);
    } catch (error) {
      handleError(res, error);
    }
  });

  // GET a single todo
  app.get("/api/todos/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const todo = await storage.getTodo(id);
      if (!todo) {
        return res.status(404).json({ message: "Todo not found" });
      }
      
      res.json(todo);
    } catch (error) {
      handleError(res, error);
    }
  });

  // POST create a new todo
  app.post("/api/todos", async (req: Request, res: Response) => {
    try {
      const validatedData = insertTodoSchema.parse(req.body);
      const newTodo = await storage.createTodo(validatedData);
      res.status(201).json(newTodo);
    } catch (error) {
      handleError(res, error);
    }
  });

  // PATCH update a todo
  app.patch("/api/todos/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      // Partial validation - only validate the fields that are present
      const updateFields = Object.keys(req.body).reduce((acc, key) => {
        if (req.body[key] !== undefined) {
          acc[key] = req.body[key];
        }
        return acc;
      }, {});
      
      const validatedData = insertTodoSchema.partial().parse(updateFields);
      
      const updatedTodo = await storage.updateTodo(id, validatedData);
      if (!updatedTodo) {
        return res.status(404).json({ message: "Todo not found" });
      }
      
      res.json(updatedTodo);
    } catch (error) {
      handleError(res, error);
    }
  });

  // DELETE a todo
  app.delete("/api/todos/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const success = await storage.deleteTodo(id);
      if (!success) {
        return res.status(404).json({ message: "Todo not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      handleError(res, error);
    }
  });

  // POST to generate a summary with OpenAI
  app.post("/api/summarize", async (_req: Request, res: Response) => {
    try {
      if (!process.env.OPENAI_API_KEY) {
        return res.status(500).json({ message: "OpenAI API key is not configured" });
      }
      
      // Get all pending todos
      const allTodos = await storage.getAllTodos();
      const pendingTodos = allTodos.filter(todo => !todo.completed);
      
      if (pendingTodos.length === 0) {
        return res.status(400).json({ message: "No pending todos to summarize" });
      }
      
      // Format todos for the prompt
      const todoText = pendingTodos.map(todo => {
        const dueDate = todo.dueDate ? new Date(todo.dueDate).toLocaleDateString() : "No due date";
        return `- (${todo.priority.toUpperCase()}) ${todo.title}: ${todo.description || 'No description'} (Due: ${dueDate})`;
      }).join("\n");
      
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are a helpful task management assistant. Summarize the following pending tasks, organizing them by priority and suggesting a plan of action. Be concise yet thorough."
          },
          {
            role: "user",
            content: `Summarize these pending tasks:\n${todoText}`
          }
        ],
        max_tokens: 500,
      });
      
      const summaryText = response.choices[0].message.content || "Unable to generate summary";
      
      // Save the summary
      const summary = {
        summaryText,
        generatedAt: new Date()
      };
      
      await storage.saveSummary(summary);
      
      res.json(summary);
    } catch (error) {
      handleError(res, error);
    }
  });

  // GET the latest summary
  app.get("/api/summary", async (_req: Request, res: Response) => {
    try {
      const summary = await storage.getLatestSummary();
      if (!summary) {
        return res.status(404).json({ message: "No summary found" });
      }
      
      res.json(summary);
    } catch (error) {
      handleError(res, error);
    }
  });

  // POST to save Slack configuration
  app.post("/api/slack/config", async (req: Request, res: Response) => {
    try {
      const config = slackConfigSchema.parse(req.body);
      const savedConfig = await storage.saveSlackConfig(config);
      res.json(savedConfig);
    } catch (error) {
      handleError(res, error);
    }
  });

  // GET Slack configuration
  app.get("/api/slack/config", async (_req: Request, res: Response) => {
    try {
      const config = await storage.getSlackConfig();
      if (!config) {
        return res.status(404).json({ message: "Slack configuration not found" });
      }
      
      res.json(config);
    } catch (error) {
      handleError(res, error);
    }
  });

  // POST to test Slack connection
  app.post("/api/slack/test", async (_req: Request, res: Response) => {
    try {
      const config = await storage.getSlackConfig();
      if (!config) {
        return res.status(404).json({ message: "Slack configuration not found" });
      }
      
      if (!process.env.SLACK_BOT_TOKEN) {
        return res.status(500).json({ message: "Slack bot token is not configured" });
      }
      
      const slackClient = new WebClient(process.env.SLACK_BOT_TOKEN);
      
      const response = await slackClient.chat.postMessage({
        channel: config.channel,
        text: "🔍 Test message from Todo Summary Assistant"
      });
      
      if (!response.ok) {
        throw new Error(`Failed to send message to Slack: ${response.error}`);
      }
      
      res.json({ success: true, message: "Test message sent successfully" });
    } catch (error) {
      handleError(res, error);
    }
  });

  // POST to send summary to Slack
  app.post("/api/slack/send", async (_req: Request, res: Response) => {
    try {
      const summary = await storage.getLatestSummary();
      if (!summary) {
        return res.status(404).json({ message: "No summary found to send" });
      }
      
      const config = await storage.getSlackConfig();
      if (!config) {
        return res.status(404).json({ message: "Slack configuration not found" });
      }
      
      if (!process.env.SLACK_BOT_TOKEN) {
        return res.status(500).json({ message: "Slack bot token is not configured" });
      }
      
      const slackClient = new WebClient(process.env.SLACK_BOT_TOKEN);
      
      // Format date for message
      const formattedDate = new Date(summary.generatedAt).toLocaleString();
      
      const response = await slackClient.chat.postMessage({
        channel: config.channel,
        blocks: [
          {
            type: "header",
            text: {
              type: "plain_text",
              text: "📋 Todo Summary",
              emoji: true
            }
          },
          {
            type: "section",
            text: {
              type: "mrkdwn",
              text: summary.summaryText
            }
          },
          {
            type: "context",
            elements: [
              {
                type: "mrkdwn",
                text: `*Generated:* ${formattedDate}`
              }
            ]
          }
        ]
      });
      
      if (!response.ok) {
        throw new Error(`Failed to send summary to Slack: ${response.error}`);
      }
      
      res.json({ success: true, message: "Summary sent to Slack successfully" });
    } catch (error) {
      handleError(res, error);
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
