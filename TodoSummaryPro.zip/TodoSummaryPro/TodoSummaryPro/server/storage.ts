import { 
  todos, type Todo, type InsertTodo,
  type TodoPriority, type Summary, type SlackConfig
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Todo methods
  getAllTodos(): Promise<Todo[]>;
  getTodo(id: number): Promise<Todo | undefined>;
  createTodo(todo: InsertTodo): Promise<Todo>;
  updateTodo(id: number, todo: Partial<InsertTodo>): Promise<Todo | undefined>;
  deleteTodo(id: number): Promise<boolean>;
  
  // Summary methods
  getLatestSummary(): Promise<Summary | undefined>;
  saveSummary(summary: Summary): Promise<Summary>;
  
  // Slack integration
  getSlackConfig(): Promise<SlackConfig | undefined>;
  saveSlackConfig(config: SlackConfig): Promise<SlackConfig>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private todoItems: Map<number, Todo>;
  private summaries: Summary[];
  private slackConfiguration: SlackConfig | undefined;
  private currentUserId: number;
  private currentTodoId: number;

  constructor() {
    this.users = new Map();
    this.todoItems = new Map();
    this.summaries = [];
    this.currentUserId = 1;
    this.currentTodoId = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Todo methods
  async getAllTodos(): Promise<Todo[]> {
    return Array.from(this.todoItems.values())
      .sort((a, b) => {
        // Sort by completion status first
        if (a.completed !== b.completed) {
          return a.completed ? 1 : -1;
        }
        
        // Then by due date if present
        if (a.dueDate && b.dueDate) {
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        }
        
        // Default to sorting by id
        return a.id - b.id;
      });
  }

  async getTodo(id: number): Promise<Todo | undefined> {
    return this.todoItems.get(id);
  }

  async createTodo(insertTodo: InsertTodo): Promise<Todo> {
    const id = this.currentTodoId++;
    const now = new Date();
    
    const todo: Todo = {
      ...insertTodo,
      id,
      createdAt: now,
      // Convert string date to Date object if present
      dueDate: insertTodo.dueDate ? new Date(insertTodo.dueDate) : null,
    };
    
    this.todoItems.set(id, todo);
    return todo;
  }

  async updateTodo(id: number, updates: Partial<InsertTodo>): Promise<Todo | undefined> {
    const existingTodo = this.todoItems.get(id);
    
    if (!existingTodo) {
      return undefined;
    }
    
    const updatedTodo: Todo = {
      ...existingTodo,
      ...updates,
      // Convert string date to Date object if present and updated
      dueDate: updates.dueDate ? new Date(updates.dueDate) : existingTodo.dueDate,
    };
    
    this.todoItems.set(id, updatedTodo);
    return updatedTodo;
  }

  async deleteTodo(id: number): Promise<boolean> {
    return this.todoItems.delete(id);
  }

  // Summary methods
  async getLatestSummary(): Promise<Summary | undefined> {
    if (this.summaries.length === 0) {
      return undefined;
    }
    
    return this.summaries[this.summaries.length - 1];
  }

  async saveSummary(summary: Summary): Promise<Summary> {
    this.summaries.push(summary);
    return summary;
  }

  // Slack integration
  async getSlackConfig(): Promise<SlackConfig | undefined> {
    return this.slackConfiguration;
  }

  async saveSlackConfig(config: SlackConfig): Promise<SlackConfig> {
    this.slackConfiguration = config;
    return config;
  }
}

export const storage = new MemStorage();
