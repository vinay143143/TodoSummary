# Todo Summary Assistant

## Overview
This project is a full-stack Todo application with AI-powered summary generation and Slack integration. Users can create, manage, and filter tasks, while the application uses OpenAI to generate summaries of tasks and can send these summaries to Slack channels.

The application uses a modern React frontend with a Node.js/Express backend. It employs Drizzle ORM for database interactions and is designed to work with PostgreSQL. The UI is built using shadcn/ui components with a Tailwind CSS styling system.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Framework**: React with TypeScript, rendered in the browser
- **Component Library**: shadcn/ui (based on Radix UI primitives)
- **Styling**: Tailwind CSS with custom theming (light/dark mode support)
- **State Management**: React Query for server state, React hooks for local state
- **Routing**: wouter for lightweight client-side routing

### Backend
- **Framework**: Express.js running on Node.js
- **API**: RESTful endpoints for CRUD operations
- **Database Access**: Drizzle ORM for type-safe database queries
- **External Integrations**: 
  - OpenAI API for generating task summaries
  - Slack API for sending summaries to Slack channels

### Database
- **ORM**: Drizzle with PostgreSQL schema definitions
- **Schema**: Includes tables for users, todos, summaries, and Slack configurations

## Key Components

### Client Components
1. **Todo Management**
   - `TodoList`: The main component for displaying and managing todos
   - `TodoItem`: Individual todo items with completion toggle, edit, and delete functionality
   - `TodoForm`: Form for creating and editing todos
   - `TodoHeader`: Search and filter functionality for todos
   - `TodoStats`: Displays statistics about todos and triggers summary generation

2. **Summary System**
   - `SummaryPanel`: Displays AI-generated summaries of todos
   - `SlackPanel`: Configuration for Slack integration and sending summaries

3. **UI System**
   - Comprehensive set of shadcn/ui components like Button, Card, Dialog, etc.
   - Light/dark mode toggle with persistent preferences

### Server Components
1. **API Routes**
   - Todo CRUD operations
   - Summary generation and retrieval
   - Slack configuration and messaging

2. **Data Storage**
   - In-memory implementation currently exists
   - Schema is ready for PostgreSQL implementation

3. **External API Integration**
   - OpenAI API client for generating summaries
   - Slack API client for sending messages

## Data Flow

1. **Todo Operations**
   - User creates/edits/deletes todos via UI → API request → Database update → UI refreshes
   - Todos can be filtered and searched locally in the UI

2. **Summary Generation**
   - User requests summary → Backend collects todos → OpenAI API generates summary → Summary stored in database → UI displays summary

3. **Slack Integration**
   - User configures Slack settings → Configuration stored in database
   - User sends summary → Backend retrieves latest summary → Slack API posts message → Confirmation displayed in UI

## External Dependencies

### Frontend Dependencies
- `@tanstack/react-query`: Data fetching and caching
- `@radix-ui/*`: UI primitives for accessible components
- `@hookform/resolvers`: Form validation with Zod
- `wouter`: Lightweight routing library
- `lucide-react`: Icon set
- `class-variance-authority`: For component styling variants
- `clsx` and `tailwind-merge`: CSS class utilities

### Backend Dependencies
- `express`: Web server framework
- `@neondatabase/serverless`: Database driver (for Neon PostgreSQL)
- `drizzle-orm`: ORM for database access
- `@slack/web-api`: Official Slack API client
- `openai`: OpenAI API client
- `zod`: Schema validation

## Deployment Strategy

The application is configured for deployment on Replit with the following setup:

1. **Development Mode**
   - `npm run dev`: Starts both backend server and frontend dev server with hot reloading
   - Vite handles frontend bundling and HMR

2. **Production Build**
   - `npm run build`: Bundles frontend assets and prepares backend for production
     - Frontend: Vite builds optimized assets
     - Backend: esbuild bundles server code
   - `npm run start`: Runs the production build

3. **Database**
   - Needs PostgreSQL connection (DATABASE_URL environment variable)
   - Migration via `npm run db:push` command

The Replit configuration (`replit.run`, `.replit`) is set up to run the development server and handle port forwarding appropriately.