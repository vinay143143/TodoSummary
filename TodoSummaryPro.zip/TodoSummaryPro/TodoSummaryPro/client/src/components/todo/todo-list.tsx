import { useState, useMemo, useCallback } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { TodoItem } from "@/components/todo/todo-item";
import { TodoHeader } from "@/components/todo/todo-header";
import { TodoStats } from "@/components/todo/todo-stats";
import { TodoForm } from "@/components/todo/todo-form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Plus, AlertTriangle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { type Todo, type InsertTodo } from "@shared/schema";

export function TodoList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTodo, setSelectedTodo] = useState<Todo | null>(null);
  
  // Query for fetching todos
  const { 
    data: todos = [], 
    isLoading,
    isError,
    error
  } = useQuery<Todo[]>({ 
    queryKey: ['/api/todos'],
  });
  
  // Calculate stats
  const stats = useMemo(() => {
    const total = todos.length;
    const completed = todos.filter(todo => todo.completed).length;
    const pending = total - completed;
    
    return { total, completed, pending };
  }, [todos]);
  
  // Filter todos based on search query and filter
  const filteredTodos = useMemo(() => {
    return todos.filter(todo => {
      // Apply search filter
      const matchesSearch = todo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (todo.description || "").toLowerCase().includes(searchQuery.toLowerCase());
      
      // Apply status filter
      const matchesFilter = filter === "all" ||
                          (filter === "completed" && todo.completed) ||
                          (filter === "pending" && !todo.completed);
      
      return matchesSearch && matchesFilter;
    });
  }, [todos, searchQuery, filter]);
  
  // Mutations
  const createTodoMutation = useMutation({
    mutationFn: async (todo: InsertTodo) => {
      const response = await apiRequest("POST", "/api/todos", todo);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      toast({
        title: "Todo created",
        description: "Your task has been created successfully.",
      });
      setIsCreateModalOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to create todo",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const updateTodoMutation = useMutation({
    mutationFn: async ({ id, todo }: { id: number; todo: Partial<InsertTodo> }) => {
      const response = await apiRequest("PATCH", `/api/todos/${id}`, todo);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      toast({
        title: "Todo updated",
        description: "Your task has been updated successfully.",
      });
      setIsEditModalOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to update todo",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const deleteTodoMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/todos/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/todos'] });
      toast({
        title: "Todo deleted",
        description: "Your task has been deleted successfully.",
      });
      setIsDeleteDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to delete todo",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handlers
  const handleCreateTodo = useCallback((todo: InsertTodo) => {
    createTodoMutation.mutate(todo);
  }, [createTodoMutation]);
  
  const handleUpdateTodo = useCallback((todo: Partial<InsertTodo>) => {
    if (selectedTodo) {
      updateTodoMutation.mutate({ id: selectedTodo.id, todo });
    }
  }, [selectedTodo, updateTodoMutation]);
  
  const handleDeleteTodo = useCallback((id: number) => {
    setSelectedTodo(todos.find(todo => todo.id === id) || null);
    setIsDeleteDialogOpen(true);
  }, [todos]);
  
  const confirmDeleteTodo = useCallback(() => {
    if (selectedTodo) {
      deleteTodoMutation.mutate(selectedTodo.id);
    }
  }, [selectedTodo, deleteTodoMutation]);
  
  const handleToggleComplete = useCallback((id: number, completed: boolean) => {
    return updateTodoMutation.mutateAsync({ id, todo: { completed } });
  }, [updateTodoMutation]);
  
  const handleEditTodo = useCallback((todo: Todo) => {
    setSelectedTodo(todo);
    setIsEditModalOpen(true);
  }, []);
  
  // Render loading state
  if (isLoading) {
    return (
      <div className="space-y-4 mb-8">
        <TodoHeader 
          onSearchChange={setSearchQuery} 
          onFilterChange={setFilter} 
        />
        {[1, 2, 3].map((i) => (
          <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-4" key={i}>
            <div className="flex items-start">
              <Skeleton className="h-5 w-5 rounded mr-3 mt-1" />
              <div className="flex-1">
                <div className="flex justify-between">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-5 w-16 rounded-full" />
                </div>
                <Skeleton className="h-4 w-5/6 mb-3" />
                <Skeleton className="h-3 w-32 mb-3" />
                <div className="flex gap-2">
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-8 w-16" />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  // Render error state
  if (isError) {
    return (
      <div className="p-6 bg-red-50 dark:bg-red-900 border-l-4 border-red-500 rounded-md">
        <div className="flex">
          <AlertTriangle className="h-6 w-6 text-red-500 dark:text-red-300 mr-3" />
          <div>
            <h3 className="text-lg font-medium text-red-800 dark:text-red-100">Error loading todos</h3>
            <p className="text-sm text-red-700 dark:text-red-200 mt-1">
              {error instanceof Error ? error.message : "An error occurred while fetching your tasks."}
            </p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/todos'] })}
            >
              Try again
            </Button>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="lg:col-span-2">
      <TodoHeader 
        onSearchChange={setSearchQuery} 
        onFilterChange={setFilter} 
      />
      
      <div className="space-y-4 mb-8">
        {filteredTodos.length > 0 ? (
          filteredTodos.map(todo => (
            <TodoItem
              key={todo.id}
              todo={todo}
              onEdit={handleEditTodo}
              onDelete={handleDeleteTodo}
              onToggleComplete={handleToggleComplete}
            />
          ))
        ) : (
          <div className="p-8 text-center bg-gray-50 dark:bg-gray-900 rounded-lg border border-dashed border-gray-300 dark:border-gray-700">
            <p className="text-gray-500 dark:text-gray-400">
              {searchQuery || filter !== "all" 
                ? "No tasks match your filters" 
                : "No tasks yet. Add your first task to get started!"}
            </p>
          </div>
        )}
      </div>
      
      <Button 
        className="fixed right-6 bottom-6 lg:static lg:w-full rounded-full lg:rounded-lg shadow-lg lg:shadow-none"
        onClick={() => setIsCreateModalOpen(true)}
      >
        <Plus className="lg:mr-2" />
        <span className="hidden lg:inline">Add New Task</span>
      </Button>
      
      <TodoStats stats={stats} className="mt-8" />
      
      {/* Create Todo Modal */}
      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
            <DialogDescription>
              Add a new task to your todo list.
            </DialogDescription>
          </DialogHeader>
          <TodoForm 
            onSubmit={handleCreateTodo} 
            isSubmitting={createTodoMutation.isPending}
            onCancel={() => setIsCreateModalOpen(false)}
          />
        </DialogContent>
      </Dialog>
      
      {/* Edit Todo Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
            <DialogDescription>
              Update your task details.
            </DialogDescription>
          </DialogHeader>
          {selectedTodo && (
            <TodoForm 
              todo={selectedTodo}
              onSubmit={handleUpdateTodo} 
              isSubmitting={updateTodoMutation.isPending}
              onCancel={() => setIsEditModalOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the task "{selectedTodo?.title}". 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-500 hover:bg-red-600"
              onClick={confirmDeleteTodo}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
