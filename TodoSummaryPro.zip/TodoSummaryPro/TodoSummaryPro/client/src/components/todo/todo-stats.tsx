import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Sparkles, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { generateSummary } from "@/lib/openai";
import { sendSummaryToSlack } from "@/lib/slack";
import { type Summary } from "@shared/schema";

interface TodoStatsProps {
  stats: {
    total: number;
    pending: number;
    completed: number;
  };
  className?: string;
}

export function TodoStats({ stats, className = "" }: TodoStatsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSendingToSlack, setIsSendingToSlack] = useState(false);
  
  // Summary generation mutation
  const generateSummaryMutation = useMutation({
    mutationFn: generateSummary,
    onSuccess: (data: Summary) => {
      queryClient.invalidateQueries({ queryKey: ['/api/summary'] });
      toast({
        title: "Summary generated",
        description: "Your task summary has been generated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to generate summary",
        description: error instanceof Error ? error.message : "An error occurred while generating summary",
        variant: "destructive",
      });
    },
  });
  
  // Send to Slack mutation
  const sendToSlackMutation = useMutation({
    mutationFn: sendSummaryToSlack,
    onSuccess: (data) => {
      toast({
        title: "Sent to Slack",
        description: "Your task summary has been sent to Slack.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to send to Slack",
        description: error instanceof Error ? error.message : "An error occurred while sending to Slack",
        variant: "destructive",
      });
    },
  });
  
  const handleGenerateSummary = () => {
    if (stats.pending === 0) {
      toast({
        title: "No pending tasks",
        description: "You need at least one pending task to generate a summary.",
        variant: "destructive",
      });
      return;
    }
    
    generateSummaryMutation.mutate();
  };
  
  const handleSendToSlack = async () => {
    try {
      setIsSendingToSlack(true);
      await sendToSlackMutation.mutateAsync();
    } finally {
      setIsSendingToSlack(false);
    }
  };
  
  return (
    <Card className={`border border-gray-200 dark:border-gray-700 ${className}`}>
      <CardContent className="pt-6">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">Todo Summary</h2>
        
        <div className="grid grid-cols-3 gap-4 mb-5">
          <div className="text-center p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
            <p className="text-gray-500 dark:text-gray-400 text-sm">Total</p>
            <p className="text-2xl font-semibold text-gray-800 dark:text-gray-100">{stats.total}</p>
          </div>
          
          <div className="text-center p-3 bg-yellow-50 dark:bg-yellow-900 rounded-lg">
            <p className="text-gray-500 dark:text-gray-400 text-sm">Pending</p>
            <p className="text-2xl font-semibold text-gray-800 dark:text-gray-100">{stats.pending}</p>
          </div>
          
          <div className="text-center p-3 bg-green-50 dark:bg-green-900 rounded-lg">
            <p className="text-gray-500 dark:text-gray-400 text-sm">Completed</p>
            <p className="text-2xl font-semibold text-gray-800 dark:text-gray-100">{stats.completed}</p>
          </div>
        </div>
        
        <div className="flex justify-between">
          <Button
            className="flex items-center"
            onClick={handleGenerateSummary}
            disabled={generateSummaryMutation.isPending || stats.pending === 0}
          >
            {generateSummaryMutation.isPending ? (
              <>
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Generating...
              </>
            ) : (
              <>
                <Sparkles className="mr-1.5 h-4 w-4" /> Generate Summary
              </>
            )}
          </Button>
          
          <Button
            variant="outline"
            className="flex items-center"
            onClick={handleSendToSlack}
            disabled={isSendingToSlack || sendToSlackMutation.isPending || generateSummaryMutation.isPending}
          >
            {sendToSlackMutation.isPending ? (
              <>
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Sending...
              </>
            ) : (
              <>
                <Send className="mr-1.5 h-4 w-4" /> Send to Slack
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
