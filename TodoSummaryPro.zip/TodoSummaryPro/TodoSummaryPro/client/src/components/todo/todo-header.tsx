import { useState } from 'react';
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

interface TodoHeaderProps {
  onSearchChange: (query: string) => void;
  onFilterChange: (filter: string) => void;
}

export function TodoHeader({ onSearchChange, onFilterChange }: TodoHeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    onSearchChange(query);
  };
  
  const handleFilterChange = (value: string) => {
    onFilterChange(value);
  };
  
  return (
    <div className="flex justify-between items-center mb-6">
      <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-100">Your Tasks</h2>
      <div className="flex space-x-2">
        <div className="relative">
          <Input
            type="text"
            className="pl-10 pr-4"
            placeholder="Search tasks..."
            value={searchQuery}
            onChange={handleSearchChange}
          />
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
        </div>
        <div>
          <Select onValueChange={handleFilterChange} defaultValue="all">
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
