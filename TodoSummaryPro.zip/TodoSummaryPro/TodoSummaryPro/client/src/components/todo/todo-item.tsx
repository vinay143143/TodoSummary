import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Calendar } from "lucide-react";
import { formatDateForDisplay, isDatePast } from "@/lib/utils/date";
import { TodoPriority, type Todo } from "@shared/schema";

interface TodoItemProps {
  todo: Todo;
  onEdit: (todo: Todo) => void;
  onDelete: (id: number) => void;
  onToggleComplete: (id: number, completed: boolean) => void;
}

export function TodoItem({ todo, onEdit, onDelete, onToggleComplete }: TodoItemProps) {
  const [isUpdating, setIsUpdating] = useState(false);
  
  const handleToggleComplete = () => {
    setIsUpdating(true);
    onToggleComplete(todo.id, !todo.completed)
      .finally(() => setIsUpdating(false));
  };
  
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case TodoPriority.HIGH:
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100";
      case TodoPriority.MEDIUM:
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100";
      case TodoPriority.LOW:
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-100";
    }
  };
  
  const isDueDatePast = todo.dueDate && !todo.completed && isDatePast(todo.dueDate);
  
  return (
    <div className={`todo-card rounded-lg border p-4 transition duration-200 ${
      todo.completed 
        ? "bg-gray-50 dark:bg-gray-900" 
        : "bg-white dark:bg-gray-800"
    } hover:shadow-md`}>
      <div className="flex items-start">
        <div className="mr-3 pt-1">
          <Checkbox 
            id={`todo-${todo.id}`}
            checked={todo.completed}
            onCheckedChange={handleToggleComplete}
            disabled={isUpdating}
            className="h-5 w-5"
          />
        </div>
        <div className="flex-1">
          <div className="flex justify-between">
            <h3 className={`text-base font-medium ${
              todo.completed 
                ? "text-gray-500 dark:text-gray-400 line-through" 
                : "text-gray-800 dark:text-gray-100"
            }`}>
              {todo.title}
            </h3>
            <Badge className={getPriorityColor(todo.priority)}>
              {todo.priority.charAt(0).toUpperCase() + todo.priority.slice(1)}
            </Badge>
          </div>
          
          {todo.description && (
            <p className={`mt-1 text-sm ${
              todo.completed 
                ? "text-gray-500 dark:text-gray-400 line-through" 
                : "text-gray-600 dark:text-gray-300"
            }`}>
              {todo.description}
            </p>
          )}
          
          {todo.dueDate && (
            <div className={`mt-2 flex items-center text-xs ${
              todo.completed 
                ? "text-gray-400 dark:text-gray-500" 
                : isDueDatePast
                  ? "text-red-500 dark:text-red-400"
                  : "text-gray-500 dark:text-gray-400"
            }`}>
              <Calendar className="mr-1 h-3 w-3" />
              <span>Due: {formatDateForDisplay(todo.dueDate)}</span>
            </div>
          )}
          
          <div className="mt-3 flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className={todo.completed ? "text-gray-400 hover:text-primary" : "text-gray-500 hover:text-primary"}
              onClick={() => onEdit(todo)}
            >
              <Pencil className="mr-1 h-3.5 w-3.5" /> Edit
            </Button>
            <Button 
              variant="ghost" 
              size="sm" 
              className={todo.completed ? "text-gray-400 hover:text-red-500" : "text-gray-500 hover:text-red-500"}
              onClick={() => onDelete(todo.id)}
            >
              <Trash2 className="mr-1 h-3.5 w-3.5" /> Delete
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
