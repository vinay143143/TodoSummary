import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, TestTube, Send, Check, Edit, Slack } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { getSlackConfig, saveSlackConfig, testSlackConnection, sendSummaryToSlack } from "@/lib/slack";
import { slackConfigSchema, type SlackConfig } from "@shared/schema";

export function SlackPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // State
  const [webhookUrl, setWebhookUrl] = useState("");
  const [channel, setChannel] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  
  // Query for fetching current Slack configuration
  const { 
    data: slackConfig, 
    isLoading: isLoadingConfig
  } = useQuery<SlackConfig | null>({ 
    queryKey: ['/api/slack/config'],
    queryFn: getSlackConfig,
  });
  
  // Set form values when config is loaded
  useEffect(() => {
    if (slackConfig) {
      setWebhookUrl(slackConfig.webhookUrl || "");
      setChannel(slackConfig.channel || "");
    }
  }, [slackConfig]);
  
  // Mutations
  const saveConfigMutation = useMutation({
    mutationFn: (config: SlackConfig) => saveSlackConfig(config),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/slack/config'] });
      toast({
        title: "Slack configured",
        description: "Slack integration has been configured successfully.",
      });
      setIsEditing(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to configure Slack",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  const testConnectionMutation = useMutation({
    mutationFn: testSlackConnection,
    onSuccess: () => {
      toast({
        title: "Connection successful",
        description: "Test message sent to Slack successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Connection failed",
        description: error instanceof Error ? error.message : "Failed to connect to Slack",
        variant: "destructive",
      });
    },
  });
  
  const sendSummaryMutation = useMutation({
    mutationFn: sendSummaryToSlack,
    onSuccess: () => {
      toast({
        title: "Summary sent",
        description: "Todo summary has been sent to Slack successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to send summary",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handlers
  const handleSaveConfig = () => {
    try {
      const config = slackConfigSchema.parse({
        webhookUrl,
        channel
      });
      
      saveConfigMutation.mutate(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Invalid configuration",
          description: error.errors[0]?.message || "Please check your inputs and try again.",
          variant: "destructive",
        });
      }
    }
  };
  
  const handleTestConnection = () => {
    testConnectionMutation.mutate();
  };
  
  const handleSendSummary = () => {
    sendSummaryMutation.mutate();
  };
  
  // Render loading state
  if (isLoadingConfig) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-800 dark:text-gray-100">Slack Integration</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center py-6">
            <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Render unconfigured state or editing state
  if (!slackConfig || isEditing) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold text-gray-800 dark:text-gray-100">Slack Integration</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
            Connect with Slack to send your todo summaries directly to a channel.
          </p>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="webhook-url">Webhook URL</Label>
              <Input 
                type="text" 
                id="webhook-url" 
                placeholder="https://hooks.slack.com/services/xxx/yyy/zzz"
                value={webhookUrl}
                onChange={(e) => setWebhookUrl(e.target.value)}
                className="mt-1"
              />
            </div>
            
            <div>
              <Label htmlFor="channel">Channel</Label>
              <Input 
                type="text" 
                id="channel" 
                placeholder="#todos"
                value={channel}
                onChange={(e) => setChannel(e.target.value)}
                className="mt-1"
              />
            </div>
            
            <Button
              className="w-full"
              onClick={handleSaveConfig}
              disabled={saveConfigMutation.isPending || !webhookUrl || !channel}
            >
              {saveConfigMutation.isPending ? (
                <>
                  <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Connecting...
                </>
              ) : (
                <>
                  <Slack className="mr-1.5 h-4 w-4" /> Connect to Slack
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Render configured state
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-800 dark:text-gray-100">Slack Integration</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="bg-green-100 dark:bg-green-900 rounded-full p-1.5 mr-2">
              <Check className="h-4 w-4 text-green-600 dark:text-green-400" />
            </div>
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Connected to Slack</p>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="text-xs text-gray-500 hover:text-gray-700"
            onClick={() => setIsEditing(true)}
          >
            <Edit className="h-3.5 w-3.5 mr-1" /> Edit
          </Button>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800 rounded-md p-3 mb-4">
          <p className="text-xs text-gray-600 dark:text-gray-400">
            <span className="font-medium">Channel:</span> {slackConfig.channel}
          </p>
        </div>
        
        <div className="space-y-3">
          <Button
            variant="outline"
            className="w-full"
            onClick={handleTestConnection}
            disabled={testConnectionMutation.isPending}
          >
            {testConnectionMutation.isPending ? (
              <>
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Testing...
              </>
            ) : (
              <>
                <TestTube className="mr-1.5 h-4 w-4" /> Test Connection
              </>
            )}
          </Button>
          
          <Button
            className="w-full"
            onClick={handleSendSummary}
            disabled={sendSummaryMutation.isPending}
          >
            {sendSummaryMutation.isPending ? (
              <>
                <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> Sending...
              </>
            ) : (
              <>
                <Send className="mr-1.5 h-4 w-4" /> Send Summary
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
