import { useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RefreshCw, Bot } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { formatDateTime } from "@/lib/utils/date";
import { getLatestSummary, generateSummary } from "@/lib/openai";
import { useToast } from "@/hooks/use-toast";
import { type Summary } from "@shared/schema";

export function SummaryPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Query for fetching latest summary
  const { 
    data: summary, 
    isLoading,
    isError,
    error,
  } = useQuery<Summary | null>({ 
    queryKey: ['/api/summary'],
    queryFn: getLatestSummary,
  });
  
  // Summary regeneration mutation
  const regenerateSummaryMutation = useMutation({
    mutationFn: generateSummary,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/summary'] });
      toast({
        title: "Summary regenerated",
        description: "Your task summary has been regenerated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to regenerate summary",
        description: error instanceof Error ? error.message : "An error occurred",
        variant: "destructive",
      });
    },
  });
  
  // Handle errors
  useEffect(() => {
    if (isError) {
      toast({
        title: "Failed to load summary",
        description: error instanceof Error ? error.message : "An error occurred while loading the summary",
        variant: "destructive",
      });
    }
  }, [isError, error, toast]);
  
  const handleRegenerateSummary = () => {
    regenerateSummaryMutation.mutate();
  };
  
  // Format summary text with paragraphs and lists
  const formatSummaryText = (text: string) => {
    // Replace line breaks with paragraphs
    const formattedText = text
      .split('\n\n')
      .map((paragraph, index) => {
        // Check if this is a list item
        if (paragraph.trim().startsWith('-') || paragraph.trim().startsWith('*')) {
          const listItems = paragraph
            .split('\n')
            .map(item => item.trim())
            .filter(item => item.length > 0)
            .map((item, itemIndex) => (
              <li key={itemIndex} className="ml-6 list-disc">{item.replace(/^[-*]\s+/, '')}</li>
            ));
          return <ul key={index} className="my-3">{listItems}</ul>;
        }
        
        return <p key={index} className="mb-3 last:mb-0">{paragraph}</p>;
      });
      
    return formattedText;
  };
  
  return (
    <div className="sticky top-6">
      <Card className="overflow-hidden mb-6">
        <CardHeader className="border-b border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 px-4 py-3">
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg font-semibold text-gray-800 dark:text-gray-100">AI Summary</CardTitle>
            <div>
              {summary?.generatedAt ? (
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Last updated: {formatDateTime(summary.generatedAt)}
                </p>
              ) : (
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Last updated: Never
                </p>
              )}
            </div>
          </div>
        </CardHeader>
        
        <CardContent className="p-0">
          {/* Loading State */}
          {isLoading && (
            <div className="p-6">
              <div className="flex flex-col items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary mb-3"></div>
                <p className="text-gray-500 dark:text-gray-400">Loading summary...</p>
              </div>
            </div>
          )}
          
          {/* Summary Generation Loading State */}
          {regenerateSummaryMutation.isPending && (
            <div className="p-6">
              <div className="flex flex-col items-center justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary mb-3"></div>
                <p className="text-gray-500 dark:text-gray-400">Generating summary...</p>
              </div>
            </div>
          )}
          
          {/* Empty State */}
          {!isLoading && !regenerateSummaryMutation.isPending && !summary && (
            <div className="text-center py-12 px-4">
              <div className="flex justify-center">
                <Bot className="h-10 w-10 text-gray-300 dark:text-gray-600 mb-2" />
              </div>
              <h3 className="text-gray-500 dark:text-gray-400 font-medium">No summary generated yet</h3>
              <p className="text-gray-400 dark:text-gray-500 text-sm mt-1">
                Click 'Generate Summary' to create a summary of your pending tasks.
              </p>
            </div>
          )}
          
          {/* Generated Summary */}
          {!isLoading && !regenerateSummaryMutation.isPending && summary && (
            <div className="p-4">
              <div className="prose prose-sm max-w-none text-gray-600 dark:text-gray-300">
                {formatSummaryText(summary.summaryText)}
              </div>
              <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-gray-500 dark:text-gray-400">Generated with AI</p>
                  <Button 
                    variant="ghost"
                    size="sm"
                    className="text-primary hover:text-blue-700"
                    onClick={handleRegenerateSummary}
                    disabled={regenerateSummaryMutation.isPending}
                  >
                    <RefreshCw className="mr-1 h-3.5 w-3.5" /> Regenerate
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
