import { apiRequest } from "./queryClient";
import { type Summary } from "@shared/schema";

/**
 * Generate a summary of all pending todos using OpenAI
 * This is a frontend wrapper for the backend API endpoint
 */
export async function generateSummary(): Promise<Summary> {
  const response = await apiRequest("POST", "/api/summarize");
  const summary: Summary = await response.json();
  return summary;
}

/**
 * Get the latest summary that has been generated
 */
export async function getLatestSummary(): Promise<Summary | null> {
  try {
    const response = await apiRequest("GET", "/api/summary");
    
    if (!response.ok) {
      if (response.status === 404) {
        return null;
      }
      throw new Error(`Failed to fetch summary: ${response.statusText}`);
    }
    
    const summary: Summary = await response.json();
    return summary;
  } catch (error) {
    console.error("Error fetching latest summary:", error);
    return null;
  }
}
