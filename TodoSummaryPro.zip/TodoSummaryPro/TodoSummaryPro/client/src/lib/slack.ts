import { apiRequest } from "./queryClient";
import { type SlackConfig } from "@shared/schema";

/**
 * Save Slack configuration
 */
export async function saveSlackConfig(config: SlackConfig): Promise<SlackConfig> {
  const response = await apiRequest("POST", "/api/slack/config", config);
  const savedConfig: SlackConfig = await response.json();
  return savedConfig;
}

/**
 * Get current Slack configuration
 */
export async function getSlackConfig(): Promise<SlackConfig | null> {
  try {
    const response = await apiRequest("GET", "/api/slack/config");
    
    if (!response.ok) {
      if (response.status === 404) {
        return null;
      }
      throw new Error(`Failed to fetch Slack config: ${response.statusText}`);
    }
    
    const config: SlackConfig = await response.json();
    return config;
  } catch (error) {
    console.error("Error fetching Slack config:", error);
    return null;
  }
}

/**
 * Test Slack connection
 */
export async function testSlackConnection(): Promise<{ success: boolean; message: string }> {
  const response = await apiRequest("POST", "/api/slack/test");
  const result = await response.json();
  return result;
}

/**
 * Send the latest summary to Slack
 */
export async function sendSummaryToSlack(): Promise<{ success: boolean; message: string }> {
  const response = await apiRequest("POST", "/api/slack/send");
  const result = await response.json();
  return result;
}
