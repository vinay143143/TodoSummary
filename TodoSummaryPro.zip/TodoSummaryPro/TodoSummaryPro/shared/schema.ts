import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Definition of priority levels
export const TodoPriority = {
  LOW: "low",
  MEDIUM: "medium",
  HIGH: "high",
} as const;

export type TodoPriority = typeof TodoPriority[keyof typeof TodoPriority];

// Definition of todo items
export const todos = pgTable("todos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  completed: boolean("completed").notNull().default(false),
  priority: text("priority").notNull().default(TodoPriority.MEDIUM),
  dueDate: timestamp("due_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTodoSchema = createInsertSchema(todos).omit({
  id: true,
  createdAt: true,
}).extend({
  // Ensure proper validation of priority
  priority: z.enum([TodoPriority.LOW, TodoPriority.MEDIUM, TodoPriority.HIGH]),
  // Make due date optional with proper format
  dueDate: z.string().optional().nullable(),
});

export type InsertTodo = z.infer<typeof insertTodoSchema>;
export type Todo = typeof todos.$inferSelect;

// Schema for summary generation
export const summarySchema = z.object({
  summaryText: z.string(),
  generatedAt: z.date().default(() => new Date()),
});

export type Summary = z.infer<typeof summarySchema>;

// Slack configuration
export const slackConfigSchema = z.object({
  webhookUrl: z.string().url(),
  channel: z.string(),
});

export type SlackConfig = z.infer<typeof slackConfigSchema>;
